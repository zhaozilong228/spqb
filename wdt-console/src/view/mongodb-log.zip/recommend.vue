<template>
  <div>
    每日推荐
  </div>
</template>

<script>
export default {
    name: 'Recommend',
    data () {
        return {
        }
    },
    created() {
    },
    watch: {
    },
    methods: {
    }
}; 
</script>

<style>

</style>
