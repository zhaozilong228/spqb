<template>
  <div>
    播放量统计
  </div>
</template>

<script>
export default {
    name: 'PlayNum',
    data () {
        return {
        }
    },
    created() {
    },
    watch: {
    },
    methods: {
    }
}; 
</script>

<style>

</style>
