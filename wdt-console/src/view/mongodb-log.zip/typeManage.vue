<template>
  <div>
    类别管理
  </div>
</template>

<script>
export default {
    name: 'TypeManage',
    data () {
        return {
        }
    },
    created() {
    },
    watch: {
    },
    methods: {
    }
}; 
</script>

<style>

</style>
